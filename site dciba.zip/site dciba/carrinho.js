document.addEventListener('DOMContentLoaded', function () {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const cartItems = document.getElementById('cartItems');

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function () {
            const product = this.getAttribute('data-product');
            const price = parseFloat(this.getAttribute('data-price'));
            
            const cartItem = document.createElement('div');
            cartItem.classList.add('cart-item');
            cartItem.innerHTML = `
                <hr class="m-1 mt-2"></hr>
                <p class="mx-3 mt-3">${product} </p> <span class="mx-3 mb-5">R$ ${price.toFixed(2)}</span>
                <hr class="m-1 mt-3"></hr>
            `;
            cartItems.appendChild(cartItem);
        });
    });
});
