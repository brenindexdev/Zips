<nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
      <div class="sidebar-sticky pt-3">
        <ul class="nav flex-column">
          <li class="nav-item">
            <a class="nav-link active" href="#">
              <span data-feather="home"></span>
              Dashboard <span class="sr-only">(current)</span>
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" href="usuario_menu.php">
              <span data-feather="user"></span>
              Usuário
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" href="categoria_menu.php">
              <span data-feather="grid"></span>
              Categoria
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" href="fornecedor_menu.php">
              <span data-feather="box"></span>
              Fornecedor
            </a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" href="estado_menu.php">
              <span data-feather="heart"></span>
              Estado
            </a>
          </li>
        
        </ul>
      </div>
</nav>