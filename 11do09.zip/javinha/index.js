function CalcularRetangulo() {
    let larguraret = parseFloat(document.getElementById('larguraret').value);
    let comprimentoret = parseFloat(document.getElementById('comprimentoret').value);
    let alturaret = parseFloat(document.getElementById('alturaret').value);

    let perimetroret = (larguraret + comprimentoret) * 2;
    let arearet = larguraret * comprimentoret;
    let volumeret = larguraret * comprimentoret * alturaret;

    document.getElementById('perimetroret').textContent = perimetroret.toFixed(2);
    document.getElementById('arearet').textContent = arearet.toFixed(2);
    document.getElementById('volumeret').textContent = volumeret.toFixed(2);
}

function CalcularCirculo() {
    let raiocirc = parseFloat(document.getElementById('raiocirc').value);
    let picirc = 3.1415;

    let diametrocirc = 2 * raiocirc;
    let perimetrocirc = 2 * picirc * raiocirc;
    let areacirc = picirc * raiocirc * raiocirc;

    document.getElementById('diametrocirc').textContent = diametrocirc.toFixed(2);
    document.getElementById('perimetrocirc').textContent = perimetrocirc.toFixed(2);
    document.getElementById('areacirc').textContent = areacirc.toFixed(2);
}
